# dlib-for-FaceRecognition
The error while installing the face Recognition module is now solved.

For complete explanation check this video:
https://youtu.be/bObLlA4mS4U
